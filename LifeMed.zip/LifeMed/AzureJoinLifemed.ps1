	hostname >C:\automate\PCName.txt
	Install-ProvisioningPackage -PackagePath "C:\automate\Lifemed\LifeMed.ppkg" -QuietInstall
	Reboot -r -f -t 00

