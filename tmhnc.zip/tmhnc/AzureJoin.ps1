	hostname >C:\automate\PCName.txt #captures current PC name to C:\automate\ as a text file, this will be used later.
	Install-ProvisioningPackage -PackagePath "C:\automate\tmhnc\thmnc.ppkg" -QuietInstall #installs the provisioning package at the referenced path
	shutdown -r -f -t 00 #reboots PC immediately

